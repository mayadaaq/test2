//
//  PrebidPlugin.h
//  PrebidPlugin
//
//  Created by Mayada Abuqdais on 2022/09/05.
//

#import <Foundation/Foundation.h>

//! Project version number for PrebidPlugin.
FOUNDATION_EXPORT double PrebidPluginVersionNumber;

//! Project version string for PrebidPlugin.
FOUNDATION_EXPORT const unsigned char PrebidPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PrebidPlugin/PublicHeader.h>


